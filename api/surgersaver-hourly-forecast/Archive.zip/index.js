// IMPORTS
var dayjs = require("dayjs");
var request = require("request");

// CONSTANTS
const AccountAPIKey = "";

// HELPER FUNCTIONS
const ERROR = {
	throw: function(type, statusCode, details, callback) {
		callback(null, {
			statusCode: statusCode,
			body: {
				error: type,
				details: details
			}
		});
	}
};

const RESPONSE = {
	send: function(body, statusCode, callback) {
		callback(null, {
			statusCode: statusCode,
			body: JSON.stringify(body)
		});
	}
};

// API REQUESTS
var endpoint = APIBaseURL + "/common/login";
var data = {
	emailId: email,
	password: password
};
var options = {
	json: data
};
request.post(endpoint, options, function(error, response, body) {
	if (error) {
		callback(null, ERROR("AccountLoginFailure", response.statusCode, error));
	} else if (response.statusCode === 200) {
		callback(null, body.authId);
	} else {
		callback(null, ERROR("AccountLoginFailure", response.statusCode, error));
	}
});

// MAIN
exports.handler = (event, context, callback) => {
	console.log(event);
};
